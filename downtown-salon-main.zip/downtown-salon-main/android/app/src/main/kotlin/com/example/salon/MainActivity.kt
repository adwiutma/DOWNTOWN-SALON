package com.example.salon

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
