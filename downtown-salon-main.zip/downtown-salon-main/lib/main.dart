import 'package:flutter/material.dart';
import 'screens/splash.dart';

/// The `lib` directory in Flutter is the main directory where you write your application's source code.
  /// Typical structure:
  /// ```
  /// lib/
  ///   |- main.dart (entry point)
  ///   |- screens/ (or pages/)
  ///   |- widgets/
  ///   |- models/
  ///   |- services/
  ///   |- utils/
  ///   |- providers/ (or blocs/)
  ///   |- constants/
  ///   |- theme/
  ///   |- routes/
  /// ```
  /// The `main.dart` file is the entry point of your application, and other directories
  /// organize different aspects of your code following clean architecture principles.

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Nota Akademika',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const SplashScreen(),
    );
  }
}

